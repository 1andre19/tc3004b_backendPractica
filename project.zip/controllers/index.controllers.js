export const getIndex = (req, res) => { res.send("hello world!") };
export const getPong = (req, res) => { res.send("pong") };
